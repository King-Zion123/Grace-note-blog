---
layout: layout.njk
title: Welcome
---

## Today’s Scripture

**Isaiah 41:10** – “So do not fear, for I am with you…”

## Featured Devotional

[Peace in the Storm](/posts/peace-in-the-storm)

Let us walk through the calm found in Christ.

## Need Prayer?

[Submit a Prayer Request](#)